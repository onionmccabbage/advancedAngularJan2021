import { NgModule } from '@angular/core';
import { SearchComponent } from './search.component';

@NgModule({
  declarations: [SearchComponent]
})
export class SearchModule {}
